package com.teamtreehouse.vending;

public class InvalidLocationException extends Exception {
    public InvalidLocationException(String s) {
        super(s);
    }
}
